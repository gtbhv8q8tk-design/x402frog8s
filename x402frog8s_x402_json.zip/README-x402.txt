README — X402 інтеграція

1. Помісти папку `.well-known` у public/ свого проєкту x402frog8s
2. Зроби commit і push у GitHub
3. На Vercel натисни "Redeploy"
4. Перевір у браузері:
   https://x402frog8s-oied.vercel.app/.well-known/x402.json
5. Через кілька хвилин ресурс зʼявиться на x402scan:
   https://www.x402scan.com/recipient/0x1DEf6d9E7ba7256dF17d01Bf7D8FA62d82A27Fc4/resources
